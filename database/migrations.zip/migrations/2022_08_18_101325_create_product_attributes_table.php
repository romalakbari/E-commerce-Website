<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_attributes', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('attribute_id')->nullable()->constrained('attributes')->casecadeOnUpdate()->cascadeOnDelete();
            $table->foreignUuid('product_id')->constrained()->casecadeOnUpdate()->cascadeOnDelete();
            // $table->foreignUuid('attribute_id')->nullable()->constrained('attribute')->casecadeOnUpdate()->cascadeOnDelete();
            $table->text('values')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_attributes');
    }
};
